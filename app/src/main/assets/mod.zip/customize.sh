#!/system/bin/sh
SKIPUNZIP=0

mkdir -p /data/adb/cos_feat_e/anymount/my_product/etc/extension
mkdir -p /data/adb/cos_feat_e/my_product/etc/extension
